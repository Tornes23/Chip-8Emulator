HOW TO USE:
- main.cpp line 18 put the rom name you want to launch between the quotes.(test_opcode.ch8, snek.ch8, petdog.ch8)

INPUT:
1 2 3 4
Q W E R
A S D F
Z X C V

